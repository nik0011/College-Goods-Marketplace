// Import required packages
const express = require('express');
const mysql = require('mysql');
const cors = require('cors');

// Initialize the Express application
const app = express();
app.use(cors());
app.use(express.json()); // To parse JSON bodies

// MySQL database connection
const db = mysql.createConnection({
    host: 'localhost',      // Your MySQL host
    user: 'root',           // Your MySQL username
    password: 'your_password', // Your MySQL root password
    database: 'college_goods_marketplace' // Your database name
});

// Connect to MySQL
db.connect(err => {
    if (err) {
        console.error('Database connection failed:', err);
        return;
    }
    console.log('Connected to the database');
});

// API endpoint to get items
app.get('/api/items', (req, res) => {
    db.query('SELECT * FROM items', (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(results);
    });
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
