// GSAP Animation for text
gsap.from(".animated-text", {
    duration: 1.5,
    opacity: 0,
    y: -50,
    stagger: 0.3,
});
// Load items dynamically from the server
fetch('http://localhost:3000/api/items')
    .then(response => response.json())
    .then(items => {
        const itemList = document.getElementById("item-list");
        
        items.forEach(item => {
            const itemDiv = document.createElement("div");
            itemDiv.className = "item";
            itemDiv.innerHTML = `
                <h2>${item.name}</h2>
                <p>Price: ${item.price}</p>
                <img src="${item.image}" alt="${item.name}" style="width: 100%; border-radius: 5px;"/>
            `;
            itemList.appendChild(itemDiv);
        });
    })
    .catch(error => console.error('Error fetching items:', error));


// Load items dynamically (example data)
const items = [
    { name: "Used Textbook", price: "$10" },
    { name: "Laptop Stand", price: "$15" },
    { name: "Desk Chair", price: "$20" },
];

const itemList = document.getElementById("item-list");

items.forEach(item => {
    const itemDiv = document.createElement("div");
    itemDiv.className = "item";
    itemDiv.innerHTML = `<h2>${item.name}</h2><p>Price: ${item.price}</p>`;
    itemList.appendChild(itemDiv);
});

// You can implement additional GSAP animations for item entries if needed
